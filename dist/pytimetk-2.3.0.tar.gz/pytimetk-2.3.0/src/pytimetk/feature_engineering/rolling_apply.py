import pandas as pd
import polars as pl
import pandas_flavor as pf
import numpy as np

from typing import Callable, List, Optional, Sequence, Tuple, Union

from pathos.multiprocessing import ProcessingPool

from pytimetk.utils.checks import (
    check_dataframe_or_groupby,
    check_date_column,
)
from pytimetk.utils.parallel_helpers import conditional_tqdm, get_threads
from pytimetk.utils.dataframe_ops import (
    FrameConversion,
    convert_to_engine,
    normalize_engine,
    resolve_pandas_groupby_frame,
    resolve_polars_group_columns,
    restore_output_type,
)


@pf.register_groupby_method
@pf.register_dataframe_method
def augment_rolling_apply(
    data: Union[
        pd.DataFrame,
        pd.core.groupby.generic.DataFrameGroupBy,
        pl.DataFrame,
        pl.dataframe.group_by.GroupBy,
    ],
    date_column: str,
    window_func: Union[Tuple[str, Callable], List[Tuple[str, Callable]]],
    window: Union[int, tuple, list] = 2,
    min_periods: Optional[int] = None,
    center: bool = False,
    threads: int = 1,
    show_progress: bool = True,
    engine: Optional[str] = "auto",
) -> Union[pd.DataFrame, pl.DataFrame]:
    """
    Apply one or more DataFrame-based rolling functions and window sizes to one
    or more columns of a DataFrame.

    Parameters
    ----------
    data : Union[pd.DataFrame, pd.core.groupby.generic.DataFrameGroupBy]
        Input data to be processed. Can be a Pandas DataFrame or a GroupBy object.
    date_column : str
        Name of the datetime column. Data is sorted by this column within each
        group.
    window_func : Union[Tuple[str, Callable], List[Tuple[str, Callable]]]
        The `window_func` parameter in the `augment_rolling_apply` function
        specifies the function(s) that operate on a rolling window with the
        consideration of multiple columns.

        The specification can be:
        - A tuple where the first element is a string representing the function's
          name and the second element is the callable function itself.
        - A list of such tuples for multiple functions.

        (See more Examples below.)

        Note: For functions targeting only a single value column without the
        need for contextual data from other columns, consider using the
        `augment_rolling` function in this library.
    window : Union[int, tuple, list], optional
        Specifies the size of the rolling windows.
        - An integer applies the same window size to all columns in `value_column`.
        - A tuple generates windows from the first to the second value (inclusive).
        - A list of integers designates multiple window sizes for each respective
          column.
    min_periods : int, optional, default None
        Minimum observations in the window to have a value. Defaults to the
        window size. If set, a value will be produced even if fewer observations
        are present than the window size.
    center : bool, optional
        If `True`, the rolling window will be centered on the current value. For
        even-sized windows, the window will be left-biased. Otherwise, it uses a
        trailing window.
    threads : int, optional, default 1
        Number of threads to use for parallel processing. If `threads` is set to
        1, parallel processing will be disabled. Set to -1 to use all available
        CPU cores.
    show_progress : bool, optional, default True
        If `True`, a progress bar will be displayed during parallel processing.

    Returns
    -------
    pd.DataFrame
        The `augment_rolling` function returns a DataFrame with new columns for
        each applied function, window size, and value column.

    Notes
    -----
    ## Performance

    This function uses parallel processing to speed up computation for large
    datasets with many time series groups:

    Parallel processing has overhead and may not be faster on small datasets.

    To use parallel processing, set `threads = -1` to use all available processors.


    Examples
    --------
    ```{python}
    import pytimetk as tk
    import pandas as pd
    import numpy as np

    # Example 1 - showcasing the rolling correlation between two columns
    # (`value1` and `value2`).
    # The correlation requires both columns as input.

    # Sample DataFrame with id, date, value1, and value2 columns.
    df = pd.DataFrame({
        'id': [1, 1, 1, 2, 2, 2],
        'date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05', '2023-01-06']),
        'value1': [10, 20, 29, 42, 53, 59],
        'value2': [2, 16, 20, 40, 41, 50],
    })

    # Compute the rolling correlation for each group of 'id'
    # Using a rolling window of size 3 and a lambda function to calculate the
    # correlation.

    rolled_df = (
        df.groupby('id')
        .augment_rolling_apply(
            date_column='date',
            window=3,
            window_func=[('corr', lambda x: x['value1'].corr(x['value2']))],  # Lambda function for correlation
            center = False,  # Not centering the rolling window
            threads = 1 # Increase threads for parallel processing (use -1 for all cores)
        )
    )
    display(rolled_df)
    ```

    ```{python}
    # Example 2 - Rolling Regression Example: Using `value1` as the dependent
    # variable and `value2` and `value3` as the independent variables. This
    # example demonstrates how to perform a rolling regression using two
    # independent variables.

    # Sample DataFrame with `id`, `date`, `value1`, `value2`, and `value3` columns.
    df = pd.DataFrame({
        'id': [1, 1, 1, 2, 2, 2],
        'date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05', '2023-01-06']),
        'value1': [10, 20, 29, 42, 53, 59],
        'value2': [5, 16, 24, 35, 45, 58],
        'value3': [2, 3, 6, 9, 10, 13]
    })

    # Define Regression Function to be applied on the rolling window.
    def regression(df):

        # Required module (scikit-learn) for regression.
        # This import statement is required inside the function to avoid errors.
        from sklearn.linear_model import LinearRegression

        model = LinearRegression()
        X = df[['value2', 'value3']]  # Independent variables
        y = df['value1']  # Dependent variable
        model.fit(X, y)
        ret = pd.Series([model.intercept_, model.coef_[0]], index=['Intercept', 'Slope'])

        return ret # Return intercept and slope as a Series

    # Compute the rolling regression for each group of `id`
    # Using a rolling window of size 3 and the regression function.
    rolled_df = (
        df.groupby('id')
        .augment_rolling_apply(
            date_column='date',
            window=3,
            window_func=[('regression', regression)]
        )
        .dropna()
    )

    # Format the results to have each regression output (slope and intercept) in
    # separate columns.

    regression_wide_df = pd.concat(rolled_df['rolling_regression_win_3'].to_list(), axis=1).T

    regression_wide_df = pd.concat([rolled_df.reset_index(drop = True), regression_wide_df], axis=1)

    display(regression_wide_df)
    ```
    """
    check_dataframe_or_groupby(data)
    check_date_column(data, date_column)

    engine_resolved = normalize_engine(engine, data)

    # Validate window argument and convert it to a consistent list format
    if not isinstance(window, (int, tuple, list)):
        raise TypeError("`window` must be an integer, tuple, or list.")
    if isinstance(window, int):
        window = [window]
    elif isinstance(window, tuple):
        window = list(range(window[0], window[1] + 1))

    # Convert single window function to list for consistent processing
    if isinstance(window_func, (str, tuple)):
        window_func = [window_func]

    threads_resolved = get_threads(threads)

    if engine_resolved == "pandas":
        conversion: FrameConversion = convert_to_engine(data, "pandas")
        prepared_data = conversion.data
        result_pd = _augment_rolling_apply_pandas(
            prepared_data,
            date_column=date_column,
            window_funcs=window_func,
            windows=window,
            min_periods=min_periods,
            center=center,
            threads_resolved=threads_resolved,
            show_progress=show_progress,
        )
        return restore_output_type(result_pd, conversion)

    if engine_resolved == "polars":
        conversion = convert_to_engine(data, "polars")
        prepared_data = conversion.data
        result_polars = _augment_rolling_apply_polars(
            prepared_data,
            date_column=date_column,
            window_funcs=window_func,
            windows=window,
            min_periods=min_periods,
            center=center,
            threads_resolved=threads_resolved,
            show_progress=show_progress,
            row_id_column=conversion.row_id_column,
            group_columns=conversion.group_columns,
        )
        return restore_output_type(result_polars, conversion)

    # Fallback: reuse pandas path for unsupported engines
    conversion = convert_to_engine(data, "pandas")
    prepared_data = conversion.data
    result_pd = _augment_rolling_apply_pandas(
        prepared_data,
        date_column=date_column,
        window_funcs=window_func,
        windows=window,
        min_periods=min_periods,
        center=center,
        threads_resolved=threads_resolved,
        show_progress=show_progress,
    )
    return restore_output_type(result_pd, conversion)


def _augment_rolling_apply_pandas(
    prepared_data: Union[pd.DataFrame, pd.core.groupby.generic.DataFrameGroupBy],
    *,
    date_column: str,
    window_funcs: List[Tuple[str, Callable]],
    windows: List[int],
    min_periods: Optional[int],
    center: bool,
    threads_resolved: int,
    show_progress: bool,
) -> pd.DataFrame:
    # Create a fresh copy of the data, leaving the original untouched
    base_frame = (
        prepared_data
        if isinstance(prepared_data, pd.DataFrame)
        else resolve_pandas_groupby_frame(prepared_data)
    )

    original_index = base_frame.index

    # Group data if it's a GroupBy object; otherwise, prepare it for the rolling calculations
    if isinstance(prepared_data, pd.core.groupby.generic.DataFrameGroupBy):
        group_names = prepared_data.grouper.names
        grouped_frame = base_frame.sort_values(by=[*group_names, date_column])
        grouped = grouped_frame.groupby(group_names)
    else:
        group_names = None
        grouped_frame = base_frame.sort_values(by=[date_column])
        grouped = [([], grouped_frame)]

    if threads_resolved == 1:
        result_dfs = []
        for group in conditional_tqdm(
            grouped,
            total=len(grouped),
            desc="Processing rolling apply...",
            display=show_progress,
        ):
            args = group, windows, window_funcs, min_periods, center
            result_dfs.append(_process_single_rolling_apply_group(args))
    else:
        # Prepare to use pathos.multiprocessing
        pool = ProcessingPool(threads_resolved)
        args = [(group, windows, window_funcs, min_periods, center) for group in grouped]
        result_dfs = list(
            conditional_tqdm(
                pool.map(_process_single_rolling_apply_group, args),
                total=len(grouped),
                desc="Processing rolling apply...",
                display=show_progress,
            )
        )

    # Combine processed dataframes and sort by index
    result_df = pd.concat(result_dfs, copy=False).sort_index()

    # result_df = pd.concat([base_frame, result_df], axis=1)
    result_df = pd.concat(
        [base_frame.reset_index(drop=True), result_df.reset_index(drop=True)],
        axis=1,
        copy=False,
    )
    result_df.index = original_index
    return result_df.sort_index()


def _augment_rolling_apply_polars(
    data: Union[pl.DataFrame, pl.dataframe.group_by.GroupBy],
    *,
    date_column: str,
    window_funcs: List[Tuple[str, Callable]],
    windows: List[int],
    min_periods: Optional[int],
    center: bool,
    threads_resolved: int,
    show_progress: bool,
    row_id_column: Optional[str],
    group_columns: Optional[Sequence[str]],
) -> pl.DataFrame:
    resolved_groups = resolve_polars_group_columns(data, group_columns)
    frame = data.df if isinstance(data, pl.dataframe.group_by.GroupBy) else data

    sort_keys = list(resolved_groups) + [date_column] if resolved_groups else [date_column]
    frame_sorted = frame.sort(sort_keys)

    partitions = (
        frame_sorted.partition_by(resolved_groups, maintain_order=True)
        if resolved_groups
        else [frame_sorted]
    )

    results: List[pl.DataFrame] = []
    iterator = conditional_tqdm(
        partitions,
        total=len(partitions),
        display=show_progress,
        desc="Processing rolling apply...",
    )
    for part in iterator:
        pandas_part = part.to_pandas()
        if resolved_groups:
            pandas_input = pandas_part.groupby(resolved_groups, sort=False)
        else:
            pandas_input = pandas_part

        pandas_result = _augment_rolling_apply_pandas(
            pandas_input,
            date_column=date_column,
            window_funcs=window_funcs,
            windows=windows,
            min_periods=min_periods,
            center=center,
            threads_resolved=threads_resolved,
            show_progress=False,
        )
        results.append(pl.from_pandas(pandas_result))

    combined = pl.concat(results, how="vertical_relaxed") if len(results) > 1 else results[0]
    combined = combined.sort(sort_keys)
    return combined


def _process_single_rolling_apply_group(args):
    group, windows, window_funcs, min_periods, center = args

    name, group_df = group
    results = {}
    for window_size in windows:
        resolved_min = window_size if min_periods is None else min_periods
        for func_spec in window_funcs:
            if isinstance(func_spec, tuple):
                func_name, func_callable = func_spec
                new_column_name = f"rolling_{func_name}_win_{window_size}"
                results[new_column_name] = _rolling_apply(
                    func_callable,
                    group_df,
                    window_size,
                    min_periods=resolved_min,
                    center=center,
                )["result"]
            else:
                raise TypeError(
                    f"Expected 'tuple', but got invalid function type: {type(func)}"
                )
    return pd.DataFrame(results, index=group_df.index)


def _rolling_apply(func, df, window_size, center, min_periods):
    num_rows = len(df)
    results = [np.nan] * num_rows
    adjusted_window = (
        window_size // 2 if center else window_size - 1
    )  # determine the offset for centering

    for center_point in range(num_rows):
        if center:
            if window_size % 2 == 0:  # left biased window if window size is even
                start = max(0, center_point - adjusted_window)
                end = min(num_rows, center_point + adjusted_window)
            else:
                start = max(0, center_point - adjusted_window)
                end = min(num_rows, center_point + adjusted_window + 1)
        else:
            start = max(0, center_point - adjusted_window)
            end = center_point + 1

        window_df = df.iloc[start:end]

        if min_periods is None:
            min_periods = window_size

        if len(window_df) >= min_periods:
            results[center_point if center else end - 1] = func(window_df)

    return pd.DataFrame({"result": results}, index=df.index)
